import React from 'react';
import { Pressable, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFonts, Manrope_400Regular, Manrope_600SemiBold, Manrope_700Bold, Manrope_800ExtraBold } from '@expo-google-fonts/manrope';
import { c, f } from './src/theme';
import { StoreProvider } from './src/store';
import { Welcome, AgeCheck, ProfileSetup } from './src/screens/Onboarding';
import { Home, Discover } from './src/screens/Home';
import { Live } from './src/screens/Live';
import { GoLive, HostLive, Moderation, Summary } from './src/screens/Creator';
import { Inbox, Chat, Call } from './src/screens/Social';
import { Profile, Wallet, Settings } from './src/screens/Me';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const navTheme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: c.bg, card: c.bgDeep, primary: c.coral, text: c.text, border: c.line } };

const tabIcon = (name) => ({ color, size }) => <Ionicons name={name} color={color} size={size} />;

function Empty() {
  return null;
}

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: { backgroundColor: c.bgDeep, borderTopColor: c.line, height: 84, paddingTop: 6 },
        tabBarActiveTintColor: c.text,
        tabBarInactiveTintColor: c.muted,
        tabBarLabelStyle: { fontFamily: f.b, fontSize: 11 },
      }}
    >
      <Tab.Screen name="Home" component={Home} options={{ tabBarIcon: tabIcon('home-outline') }} />
      <Tab.Screen name="Discover" component={Discover} options={{ tabBarIcon: tabIcon('compass-outline') }} />
      <Tab.Screen
        name="GoLiveTab"
        component={Empty}
        options={({ navigation }) => ({
          tabBarButton: () => (
            <View style={{ flex: 1, alignItems: 'center' }}>
              <Pressable accessibilityRole="button" accessibilityLabel="Go Live" onPress={() => navigation.navigate('GoLive')} style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: c.coral, alignItems: 'center', justifyContent: 'center', marginTop: -14 }}>
                <Ionicons name="add" size={30} color={c.ink} />
              </Pressable>
            </View>
          ),
        })}
      />
      <Tab.Screen name="Inbox" component={Inbox} options={{ tabBarIcon: tabIcon('chatbubble-outline') }} />
      <Tab.Screen name="Profile" component={Profile} options={{ tabBarIcon: tabIcon('person-outline') }} />
    </Tab.Navigator>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ Manrope_400Regular, Manrope_600SemiBold, Manrope_700Bold, Manrope_800ExtraBold });
  if (!fontsLoaded) return <View style={{ flex: 1, backgroundColor: c.bg }} />;

  return (
    <SafeAreaProvider>
      <StoreProvider>
        <NavigationContainer theme={navTheme}>
          <StatusBar style="light" />
          <Stack.Navigator initialRouteName="Welcome" screenOptions={{ headerShown: false, contentStyle: { backgroundColor: c.bg } }}>
            <Stack.Screen name="Welcome" component={Welcome} />
            <Stack.Screen name="AgeCheck" component={AgeCheck} />
            <Stack.Screen name="ProfileSetup" component={ProfileSetup} />
            <Stack.Screen name="Tabs" component={Tabs} />
            <Stack.Screen name="Live" component={Live} />
            <Stack.Screen name="GoLive" component={GoLive} options={{ presentation: 'fullScreenModal' }} />
            <Stack.Screen name="HostLive" component={HostLive} options={{ gestureEnabled: false }} />
            <Stack.Screen name="Moderation" component={Moderation} options={{ presentation: 'modal' }} />
            <Stack.Screen name="Summary" component={Summary} options={{ gestureEnabled: false }} />
            <Stack.Screen name="Chat" component={Chat} />
            <Stack.Screen name="Call" component={Call} options={{ presentation: 'fullScreenModal' }} />
            <Stack.Screen name="Wallet" component={Wallet} />
            <Stack.Screen name="Settings" component={Settings} />
          </Stack.Navigator>
        </NavigationContainer>
      </StoreProvider>
    </SafeAreaProvider>
  );
}
