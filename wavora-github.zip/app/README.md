# Wavora app (first working build)

A React Native app made with Expo. It covers sign-up, the home feed, Discover, watching a live stream, sending gifts, going live as a host, the stream summary, Inbox, chat, video calls, wallet and settings.

## Run it on your phone

You need a computer with [Node.js](https://nodejs.org) (version 20 or newer) and the free **Expo Go** app on your phone.

1. Create a fresh Expo project:
   ```
   npx create-expo-app@latest wavora --template blank
   cd wavora
   ```
2. Add the libraries this app uses (Expo picks versions that match):
   ```
   npx expo install @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs react-native-screens react-native-safe-area-context expo-font @expo-google-fonts/manrope expo-status-bar
   ```
3. Copy `App.js` and the `src` folder from this download into the `wavora` folder, replacing the `App.js` that is there.
4. Start it:
   ```
   npx expo start
   ```
   Scan the QR code with your phone's camera (iPhone) or the Expo Go app (Android).

## What works

- Sign-up flow, with username checks and interest picking
- Feed with category filter, search on Discover
- Live room: follow, comment, hearts, gifts that really deduct Sparks, report and block
- Going live: setup, a host view with a timer, simulated viewers and gifts, guest requests and moderation tools, and a summary that calculates earnings at £0.45 per 100 Sparks
- Inbox and chat (messages send), call screen with mute and camera controls
- Wallet: buy Sparks (checks your daily spend limit), withdraw (checks the £20 minimum), activity list

## What is simulated (needs a backend next)

Search the code for `shortcut:` to find each one.

- No real video yet: camera preview, streams and calls are placeholders. Next: `expo-camera` plus a real-time video service (for example LiveKit).
- No server: data resets when the app restarts. Next: accounts, database and real-time chat.
- No real payments: purchases go through Apple and Google in-app purchase in production.
- Age check is a placeholder screen: plug in the chosen age-assurance provider.

## Checks

Money maths has a self-check: `node src/money.test.mjs`
