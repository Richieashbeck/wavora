import React from 'react';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { c, f } from './theme';

export function Txt({ w = 'm', size = 15, color = c.text, style, ...p }) {
  return <Text {...p} style={[{ fontFamily: f[w], fontSize: size, color }, style]} />;
}

export function Screen({ children, style, edges = ['top', 'bottom'] }) {
  return (
    <SafeAreaView edges={edges} style={[{ flex: 1, backgroundColor: c.bg }, style]}>
      {children}
    </SafeAreaView>
  );
}

const btnKinds = {
  primary: { bg: c.coral, fg: c.ink, border: c.coral },
  gold: { bg: c.gold, fg: c.ink, border: c.gold },
  light: { bg: c.text, fg: c.ink, border: c.text },
  outline: { bg: 'transparent', fg: c.text, border: c.border },
};

export function Btn({ title, onPress, kind = 'primary', small, style, disabled }) {
  const k = btnKinds[kind];
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        { height: small ? 40 : 52, paddingHorizontal: small ? 14 : 20, borderRadius: small ? 20 : 26, backgroundColor: k.bg, borderWidth: 1, borderColor: k.border, alignItems: 'center', justifyContent: 'center', opacity: pressed || disabled ? 0.7 : 1 },
        style,
      ]}
    >
      <Txt w="x" size={small ? 13 : 16} color={k.fg}>{title}</Txt>
    </Pressable>
  );
}

export function Chip({ label, on, onPress }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!on }}
      onPress={onPress}
      style={{ height: 38, paddingHorizontal: 16, borderRadius: 19, borderWidth: 1, borderColor: on ? c.text : c.border, backgroundColor: on ? c.text : 'transparent', justifyContent: 'center' }}
    >
      <Txt w="b" size={14} color={on ? c.ink : c.text}>{label}</Txt>
    </Pressable>
  );
}

export function Segmented({ options, value, onChange }) {
  return (
    <View accessibilityRole="radiogroup" style={{ flexDirection: 'row', gap: 6 }}>
      {options.map((o) => {
        const on = o === value;
        return (
          <Pressable
            key={o}
            accessibilityRole="radio"
            accessibilityState={{ checked: on }}
            onPress={() => onChange(o)}
            style={{ flex: 1, height: 42, borderRadius: 12, borderWidth: 1, borderColor: on ? c.text : c.border, backgroundColor: on ? c.text : 'transparent', alignItems: 'center', justifyContent: 'center' }}
          >
            <Txt w="b" size={13} color={on ? c.ink : c.text}>{o}</Txt>
          </Pressable>
        );
      })}
    </View>
  );
}

export function ToggleRow({ label, value, onChange, last }) {
  return (
    <View style={[styles.row, !last && styles.rowLine]}>
      <Txt>{label}</Txt>
      <Switch accessibilityLabel={label} value={value} onValueChange={onChange} trackColor={{ true: c.teal, false: c.border }} thumbColor={c.text} />
    </View>
  );
}

export function LinkRow({ label, value, onPress, last, color = c.text }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={[styles.row, !last && styles.rowLine]}>
      <Txt color={color}>{label}</Txt>
      {value ? <Txt color={c.muted}>{value}</Txt> : <Ionicons name="chevron-forward" size={18} color={c.muted} />}
    </Pressable>
  );
}

export function Card({ children, style }) {
  return <View style={[{ backgroundColor: c.card, borderRadius: 16 }, style]}>{children}</View>;
}

export function Avatar({ initials, color, size = 44, ring }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, borderWidth: ring ? 3 : 0, borderColor: ring || 'transparent', alignItems: 'center', justifyContent: 'center' }}>
      <Txt w="x" size={size / 3.2}>{initials}</Txt>
    </View>
  );
}

export function Badge({ label, bg = c.teal, fg = c.ink }) {
  return (
    <View style={{ backgroundColor: bg, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'flex-start' }}>
      <Txt w="x" size={11} color={fg}>{label}</Txt>
    </View>
  );
}

export function Header({ title, onBack, right }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, gap: 4 }}>
      {onBack ? (
        <Pressable accessibilityRole="button" accessibilityLabel="Back" onPress={onBack} style={styles.iconBtn}>
          <Ionicons name="chevron-back" size={24} color={c.text} />
        </Pressable>
      ) : null}
      <Txt w="x" size={22} style={{ flex: 1, paddingLeft: onBack ? 0 : 8 }}>{title}</Txt>
      {right}
    </View>
  );
}

export function IconBtn({ name, label, onPress, bg = c.line, color = c.text, size = 44 }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={name} size={size * 0.45} color={color} />
    </Pressable>
  );
}

export const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 52, paddingHorizontal: 16 },
  rowLine: { borderBottomWidth: 1, borderBottomColor: c.line },
  iconBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  input: { height: 48, borderRadius: 14, borderWidth: 1, borderColor: c.border, backgroundColor: c.card, color: c.text, paddingHorizontal: 14, fontFamily: f.m, fontSize: 15 },
});
