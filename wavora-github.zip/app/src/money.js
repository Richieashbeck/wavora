// All money is handled in whole pence to avoid floating-point drift.
export const PENCE_PER_100_SPARKS = 99; // buyer price: 100 Sparks = £0.99
export const CREATOR_PENCE_PER_100_SPARKS = 45; // published creator rate (75% of net)
export const MIN_WITHDRAWAL_PENCE = 2000; // £20

export const sparksToPence = (sparks) => Math.round((sparks * PENCE_PER_100_SPARKS) / 100);
export const creatorPence = (sparks) => Math.round((sparks * CREATOR_PENCE_PER_100_SPARKS) / 100);
export const formatGbp = (pence) => '£' + (pence / 100).toFixed(2);
export const formatSparks = (n) => n.toLocaleString('en-GB') + ' Sparks';

// Returns an error message, or null when the gift can be sent.
export function giftError(balance, giftSparks) {
  if (giftSparks <= 0) return 'Pick a gift first.';
  if (giftSparks > balance) return 'Not enough Sparks. Top up in your wallet.';
  return null;
}

// Spend limits apply to real-money purchases, not to gifting Sparks you already own.
export function purchaseError(spentTodayPence, dailyLimitPence, pricePence) {
  if (spentTodayPence + pricePence > dailyLimitPence) {
    return 'This would go over your daily limit of ' + formatGbp(dailyLimitPence) + '.';
  }
  return null;
}

export function withdrawError(availablePence) {
  if (availablePence < MIN_WITHDRAWAL_PENCE) {
    return 'You can withdraw once you have ' + formatGbp(MIN_WITHDRAWAL_PENCE) + ' available.';
  }
  return null;
}
