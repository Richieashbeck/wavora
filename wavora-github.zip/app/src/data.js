// Sample content so the app has something to show before a backend exists.
export const streams = [
  { id: 'maya', host: 'maya.sings', name: 'Maya Santos', initials: 'MS', title: 'Acoustic requests', viewers: '1.2k', color: '#45305E', avatar: '#6B4E8F', category: 'Music' },
  { id: 'theo', host: 'theo.talks', name: 'Theo', initials: 'TT', title: 'Late-night chat', viewers: '486', color: '#2B3F5E', avatar: '#3E6A8F', category: 'Just Chatting' },
  { id: 'laugh', host: 'laughlab', name: 'Laugh Lab', initials: 'LL', title: 'Open mic comedy', viewers: '2.8k', color: '#5A2E3C', avatar: '#8F4E5E', category: 'Comedy' },
  { id: 'lucia', host: 'profe.lucia', name: 'Lucía', initials: 'PL', title: 'Spanish for beginners', viewers: '312', color: '#224A4C', avatar: '#4E8F7A', category: 'Languages' },
];

export const newStreamers = [
  { id: 'jun', host: 'jun.draws', initials: 'JN', color: '#6B4E8F' },
  { id: 'ama', host: 'ama.keys', initials: 'AK', color: '#3E6A8F' },
  { id: 'rosa', host: 'rosa.cooks', initials: 'RS', color: '#8F4E5E' },
  { id: 'ben', host: 'ben.lifts', initials: 'BO', color: '#4E8F7A' },
];

export const categories = ['All', 'Music', 'Just Chatting', 'Comedy', 'Talent', 'Gaming', 'Dance', 'Languages', 'Creative', 'Cooking'];

export const gifts = [
  { id: 'heart', name: 'Heart', sparks: 1, color: '#FF5A4E' },
  { id: 'clap', name: 'Clap', sparks: 5, color: '#FFB627' },
  { id: 'rose', name: 'Rose', sparks: 10, color: '#E0446F' },
  { id: 'smile', name: 'Smile', sparks: 20, color: '#FFD27A' },
  { id: 'guitar', name: 'Guitar', sparks: 100, color: '#14B8A6' },
  { id: 'confetti', name: 'Confetti', sparks: 300, color: '#8F7AE0' },
  { id: 'rocket', name: 'Rocket', sparks: 600, color: '#5AA9FF' },
  { id: 'crown', name: 'Crown', sparks: 1500, color: '#FFB627' },
];

export const sparkBundles = [
  { sparks: 100, pence: 99 },
  { sparks: 550, pence: 499 },
  { sparks: 1150, pence: 999 },
  { sparks: 5750, pence: 4999 },
];

export const conversations = [
  { id: 'maya', name: 'maya.sings', initials: 'MS', color: '#6B4E8F', verified: true, time: '21:14' },
  { id: 'theo', name: 'theo.talks', initials: 'TT', color: '#3E6A8F', time: 'Yesterday' },
  { id: 'crew', name: 'Friday crew (8)', initials: 'FC', color: '#4E8F7A', time: 'Mon' },
  { id: 'jake', name: 'jake_k02', initials: 'JK', color: '#8F4E5E', newAccount: true, time: 'Sun' },
];

export const initialMessages = {
  maya: [
    { from: 'them', text: 'Thanks for the rocket last night!' },
    { from: 'them', text: "Same time Friday? I'm doing a covers set." },
  ],
  theo: [{ from: 'them', text: 'Good chat tonight, thanks for joining.' }],
  crew: [{ from: 'them', text: 'priya.k: who is hosting next week?' }],
  jake: [{ from: 'them', text: 'Missed video call' }],
};

export const reportReasons = ['Inappropriate content', 'Harassment or bullying', 'Fake account', 'Spam', 'Might be under 18', 'Fraud or scam', 'Something else'];
