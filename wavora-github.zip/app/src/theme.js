export const c = {
  bg: '#1E1530',
  bgDeep: '#160F24',
  card: '#241A36',
  line: '#2C2240',
  border: '#3D3254',
  text: '#FFF9F5',
  sub: '#D9D1E6',
  muted: '#B8AECB',
  coral: '#FF5A4E',
  gold: '#FFB627',
  teal: '#14B8A6',
  tealText: '#8FE3D8',
  ink: '#1F1B24',
  danger: '#D7263D',
  scrim: 'rgba(20,14,32,0.65)',
};

export const f = {
  r: 'Manrope_400Regular',
  m: 'Manrope_600SemiBold',
  b: 'Manrope_700Bold',
  x: 'Manrope_800ExtraBold',
};
