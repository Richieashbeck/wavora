import React, { createContext, useContext, useState } from 'react';
import { initialMessages } from './data';
import { giftError, purchaseError, withdrawError, formatGbp, formatSparks } from './money';

const Store = createContext(null);
export const useStore = () => useContext(Store);

// shortcut: state lives in memory only and resets on reload; swap for a real backend + secure storage before launch.
export function StoreProvider({ children }) {
  const [s, setS] = useState({
    sparks: 1150,
    spentTodayPence: 640,
    dailyLimitPence: 2000,
    availablePence: 31240,
    pendingPence: 4815,
    following: {},
    messages: initialMessages,
    activity: [
      { title: 'Gifts received', detail: '14 Oct · 6,940 Sparks', amount: '+£31.23' },
      { title: 'Payout to bank ••42', detail: '12 Oct', amount: '−£250.00' },
    ],
    prefs: { online: true, hidden: false, theme: 'Dark' },
    profile: { name: 'Maya Santos', username: 'maya.sings', interests: ['Music', 'Comedy'] },
  });

  const update = (patch) => setS((prev) => ({ ...prev, ...patch(prev) }));

  const api = {
    ...s,
    sendGift(gift, host) {
      const err = giftError(s.sparks, gift.sparks);
      if (err) return err;
      update((p) => ({
        sparks: p.sparks - gift.sparks,
        activity: [{ title: 'Sent ' + gift.name + ' to ' + host, detail: 'Just now', amount: formatSparks(gift.sparks) }, ...p.activity],
      }));
      return null;
    },
    buySparks(bundle) {
      const err = purchaseError(s.spentTodayPence, s.dailyLimitPence, bundle.pence);
      if (err) return err;
      // shortcut: no payment provider yet; real purchases go through StoreKit / Play Billing.
      update((p) => ({
        sparks: p.sparks + bundle.sparks,
        spentTodayPence: p.spentTodayPence + bundle.pence,
        activity: [{ title: 'Bought ' + formatSparks(bundle.sparks), detail: 'Just now', amount: formatGbp(bundle.pence) }, ...p.activity],
      }));
      return null;
    },
    withdraw() {
      const err = withdrawError(s.availablePence);
      if (err) return err;
      update((p) => ({
        availablePence: 0,
        activity: [{ title: 'Payout to bank ••42', detail: 'Just now · arrives in about 3 working days', amount: '−' + formatGbp(p.availablePence) }, ...p.activity],
      }));
      return null;
    },
    addEarnings(pence) {
      update((p) => ({ pendingPence: p.pendingPence + pence }));
    },
    toggleFollow(id) {
      update((p) => ({ following: { ...p.following, [id]: !p.following[id] } }));
    },
    sendMessage(convoId, text) {
      update((p) => ({ messages: { ...p.messages, [convoId]: [...(p.messages[convoId] || []), { from: 'me', text }] } }));
    },
    setPref(key, value) {
      update((p) => ({ prefs: { ...p.prefs, [key]: value } }));
    },
    setProfile(profile) {
      update((p) => ({ profile: { ...p.profile, ...profile } }));
    },
  };

  return <Store.Provider value={api}>{children}</Store.Provider>;
}
