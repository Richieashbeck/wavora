import React, { useEffect, useRef, useState } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Avatar, Badge, Btn, Card, IconBtn, Screen, Segmented, ToggleRow, Txt, styles } from '../ui';
import { c } from '../theme';
import { creatorPence, formatGbp, formatSparks } from '../money';
import { useStore } from '../store';

export function GoLive({ navigation }) {
  const [title, setTitle] = useState('Acoustic requests, all night');
  const [audience, setAudience] = useState('Public');
  const [opts, setOpts] = useState({ comments: true, gifts: true, guests: true, beauty: false });
  const set = (k) => (v) => setOpts((p) => ({ ...p, [k]: v }));

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ height: 260, backgroundColor: '#3A2B52', alignItems: 'center', justifyContent: 'center' }}>
        {/* shortcut: placeholder; add expo-camera for the real preview */}
        <Txt color={c.muted}>Camera preview</Txt>
        <SafeAreaView edges={['top']} style={{ position: 'absolute', top: 0, left: 16, right: 16, flexDirection: 'row', justifyContent: 'space-between' }}>
          <IconBtn name="close" label="Cancel" bg={c.scrim} onPress={() => navigation.goBack()} />
          <IconBtn name="camera-reverse-outline" label="Flip camera" bg={c.scrim} onPress={() => {}} />
        </SafeAreaView>
      </View>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
        <View>
          <Txt w="b" size={13} color={c.muted} style={{ marginBottom: 6 }}>Stream title</Txt>
          <TextInput accessibilityLabel="Stream title" value={title} onChangeText={setTitle} maxLength={80} style={styles.input} />
        </View>
        <View>
          <Txt w="b" size={13} color={c.muted} style={{ marginBottom: 6 }}>Who can watch</Txt>
          <Segmented options={['Public', 'Followers', 'Fan club', 'Private']} value={audience} onChange={setAudience} />
        </View>
        <Card>
          <ToggleRow label="Comments" value={opts.comments} onChange={set('comments')} />
          <ToggleRow label="Gifts" value={opts.gifts} onChange={set('gifts')} />
          <ToggleRow label="Guest requests" value={opts.guests} onChange={set('guests')} />
          <ToggleRow label="Beauty filter" value={opts.beauty} onChange={set('beauty')} last />
        </Card>
        <Card style={{ padding: 12 }}><Txt size={13} color={c.sub}>You keep 75% of gift value: £0.45 for every 100 Sparks you receive.</Txt></Card>
        <Btn title="Go Live" disabled={!title.trim()} onPress={() => navigation.replace('HostLive', { title: title.trim(), audience })} />
      </ScrollView>
    </View>
  );
}

const clock = (sec) => Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0');

export function HostLive({ route, navigation }) {
  const [seconds, setSeconds] = useState(0);
  const [sparks, setSparks] = useState(0);
  const [muted, setMuted] = useState(false);
  const [request, setRequest] = useState(true);
  const [guest, setGuest] = useState(null);
  const ref = useRef({ seconds: 0, sparks: 0 });

  useEffect(() => {
    // shortcut: viewers and gifts are simulated; replace with the real-time stream and gift events.
    const t = setInterval(() => {
      ref.current.seconds += 1;
      if (ref.current.seconds % 4 === 0) ref.current.sparks += 50;
      setSeconds(ref.current.seconds);
      setSparks(ref.current.sparks);
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const viewers = 40 + seconds * 3;

  return (
    <View style={{ flex: 1, backgroundColor: '#3A2B52' }}>
      <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, alignItems: 'center', justifyContent: 'center' }}>
        <Txt color={c.muted}>Your camera{guest ? ' + ' + guest : ''}</Txt>
      </View>
      <SafeAreaView style={{ flex: 1, padding: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Badge label={'LIVE ' + clock(seconds)} bg={c.coral} />
          <View style={{ backgroundColor: c.scrim, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}><Txt w="b" size={12}>{viewers.toLocaleString('en-GB')} watching</Txt></View>
          <View style={{ flex: 1 }} />
          <Btn small kind="light" title="End" onPress={() => navigation.replace('Summary', { seconds, sparks, peak: viewers, title: route.params?.title })} />
        </View>

        <View style={{ flexDirection: 'row', backgroundColor: c.scrim, borderRadius: 14, padding: 10, marginTop: 12 }}>
          <View style={{ flex: 1, alignItems: 'center' }}><Txt w="x" color={c.tealText}>+{Math.floor(seconds / 6)}</Txt><Txt size={11} color={c.sub}>new followers</Txt></View>
          <View style={{ flex: 1, alignItems: 'center' }}><Txt w="x" color={c.gold}>{sparks.toLocaleString('en-GB')}</Txt><Txt size={11} color={c.sub}>Sparks</Txt></View>
          <View style={{ flex: 1, alignItems: 'center' }}><Txt w="x">{formatGbp(creatorPence(sparks))}</Txt><Txt size={11} color={c.sub}>you've earned</Txt></View>
        </View>

        {request ? (
          <Card style={{ padding: 14, marginTop: 12, backgroundColor: c.bg }}>
            <Txt w="x" size={14}>ama.keys wants to join on screen</Txt>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 10 }}>
              <Avatar initials="AK" color="#3E6A8F" size={36} />
              <Txt w="b" size={14} style={{ flex: 1 }}>ama.keys <Txt size={14} color={c.tealText}>· verified</Txt></Txt>
              <Btn small kind="outline" title="Decline" onPress={() => setRequest(false)} />
              <Btn small kind="light" title="Accept" onPress={() => { setRequest(false); setGuest('ama.keys'); }} />
            </View>
          </Card>
        ) : null}

        <View style={{ flex: 1 }} />
        <View style={{ gap: 8, marginBottom: 16 }}>
          <View style={{ alignSelf: 'flex-start', backgroundColor: 'rgba(20,14,32,0.55)', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6 }}><Txt size={14}><Txt w="x" size={14} color={c.tealText}>sam_r </Txt>this is so good</Txt></View>
          <Pressable accessibilityRole="button" onPress={() => navigation.navigate('Moderation')} style={{ alignSelf: 'flex-start', backgroundColor: 'rgba(20,14,32,0.55)', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6 }}>
            <Txt size={14} color={c.muted}>troll_99 message hidden by filter · <Txt w="b" size={14} color={c.gold}>Review</Txt></Txt>
          </Pressable>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
          <IconBtn name="shield-checkmark-outline" label="Moderation tools" bg={c.scrim} size={52} onPress={() => navigation.navigate('Moderation')} />
          <IconBtn name="person-add-outline" label="Guests" bg={c.scrim} size={52} onPress={() => setRequest(true)} />
          <IconBtn name="sparkles-outline" label="Filters" bg={c.scrim} size={52} onPress={() => {}} />
          <IconBtn name={muted ? 'mic-off' : 'mic-outline'} label={muted ? 'Unmute' : 'Mute'} bg={muted ? c.text : c.scrim} color={muted ? c.ink : c.text} size={52} onPress={() => setMuted(!muted)} />
        </View>
      </SafeAreaView>
    </View>
  );
}

export function Moderation({ navigation }) {
  const [slow, setSlow] = useState('Off');
  const [followersOnly, setFollowersOnly] = useState(false);
  const [done, setDone] = useState(null);

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Txt w="x" size={20}>Keep your stream friendly</Txt>
          <IconBtn name="close" label="Close" onPress={() => navigation.goBack()} />
        </View>
        <View>
          <Txt w="b" size={13} color={c.muted} style={{ marginBottom: 6 }}>Slow mode</Txt>
          <Segmented options={['Off', '5 s', '15 s', '60 s']} value={slow} onChange={setSlow} />
        </View>
        <Card>
          <ToggleRow label="Followers-only chat" value={followersOnly} onChange={setFollowersOnly} last />
        </Card>
        <Txt w="b" size={13} color={c.muted}>Needs your attention</Txt>
        <Card style={{ padding: 14 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Avatar initials="TR" color="#5A5A6E" size={40} />
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}><Txt w="b">troll_99</Txt><Badge label="New account" bg={c.gold} /></View>
              <Txt size={13} color={c.sub}>3 messages hidden by the filter</Txt>
            </View>
          </View>
          {done ? (
            <Txt w="b" size={13} color={c.tealText} style={{ marginTop: 10 }}>{done}. Our safety team has also been told.</Txt>
          ) : (
            <View style={{ flexDirection: 'row', gap: 6, marginTop: 12 }}>
              <Btn small kind="outline" style={{ flex: 1 }} title="Mute 10 min" onPress={() => setDone('Muted for 10 minutes')} />
              <Btn small kind="outline" style={{ flex: 1 }} title="Remove" onPress={() => setDone('Removed from your stream')} />
              <Btn small style={{ flex: 1 }} title="Ban" onPress={() => setDone('Banned')} />
            </View>
          )}
        </Card>
        <Txt size={12} color={c.muted}>Banned people can't rejoin from a new account on the same verified identity. They can appeal, and a reviewer decides within 72 hours.</Txt>
      </ScrollView>
    </Screen>
  );
}

export function Summary({ route, navigation }) {
  const store = useStore();
  const { seconds = 0, sparks = 0, peak = 0 } = route.params || {};
  const earned = creatorPence(sparks);
  const [rec, setRec] = useState('Publish replay to followers');
  const mins = Math.max(1, Math.round(seconds / 60));

  const stats = [
    ['Length', clock(seconds)],
    ['Peak viewers', peak.toLocaleString('en-GB')],
    ['New followers', '+' + Math.floor(seconds / 6)],
    ['Sparks', sparks.toLocaleString('en-GB')],
    ['You earned', formatGbp(earned)],
    ['Avg watch', Math.max(1, Math.round(mins * 0.6)) + ' min'],
  ];

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Txt w="b" size={13} color={c.muted}>Stream ended</Txt>
        <Txt w="x" size={26} style={{ marginTop: 4 }}>Great show, {store.profile.name.split(' ')[0]}</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 }}>
          {stats.map(([k, v]) => (
            <Card key={k} style={{ width: '31.5%', padding: 12 }}>
              <Txt size={11} color={c.muted}>{k}</Txt>
              <Txt w="x" size={18} color={k === 'You earned' ? c.gold : c.text}>{v}</Txt>
            </Card>
          ))}
        </View>
        <Txt size={13} color={c.sub} style={{ marginTop: 10 }}>{formatSparks(sparks)} × £0.45 per 100 = {formatGbp(earned)}. It shows as pending in your wallet for 3 days.</Txt>
        <Txt w="x" size={16} style={{ marginTop: 18, marginBottom: 8 }}>Recording</Txt>
        <View style={{ gap: 6 }}>
          {['Publish replay to followers', 'Publish replay publicly', 'Keep private for 30 days', 'Delete recording'].map((o) => (
            <Pressable key={o} accessibilityRole="radio" accessibilityState={{ checked: rec === o }} onPress={() => setRec(o)} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', height: 46, paddingHorizontal: 14, borderRadius: 12, backgroundColor: c.card, borderWidth: 1, borderColor: rec === o ? c.coral : 'transparent' }}>
              <Txt size={14}>{o}</Txt>
              <View style={{ width: 18, height: 18, borderRadius: 9, borderWidth: rec === o ? 5 : 2, borderColor: rec === o ? c.coral : '#6E6488' }} />
            </Pressable>
          ))}
        </View>
        <Btn style={{ marginTop: 20 }} title="Done" onPress={() => { store.addEarnings(earned); navigation.reset({ index: 0, routes: [{ name: 'Tabs', params: { screen: 'Profile' } }] }); }} />
      </ScrollView>
    </Screen>
  );
}
