import React, { useState } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Btn, Chip, Screen, Txt, styles } from '../ui';
import { c } from '../theme';
import { categories } from '../data';
import { useStore } from '../store';

const goHome = (navigation) => navigation.reset({ index: 0, routes: [{ name: 'Tabs' }] });

export function Welcome({ navigation }) {
  return (
    <Screen style={{ paddingHorizontal: 24, paddingBottom: 16 }}>
      <View style={{ flex: 1, justifyContent: 'center', gap: 14 }}>
        <Txt w="x" size={48} color={c.coral}>wavora</Txt>
        <Txt w="x" size={28}>Go live. Meet people.{'\n'}Fair for everyone.</Txt>
        <Txt size={16} color={c.sub}>Watch and chat with creators worldwide. Prices in pounds, creators keep 75%, and every account is a verified adult.</Txt>
      </View>
      <View style={{ gap: 10 }}>
        <Btn kind="light" title="Continue with Apple" onPress={() => navigation.navigate('AgeCheck')} />
        <Btn kind="outline" title="Continue with Google" onPress={() => navigation.navigate('AgeCheck')} />
        <Btn kind="outline" title="Use phone or email" onPress={() => navigation.navigate('AgeCheck')} />
        <Pressable accessibilityRole="button" onPress={() => goHome(navigation)} style={{ height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Txt w="b" color={c.gold}>Browse as a guest</Txt>
        </Pressable>
        <Txt size={12} color={c.muted} style={{ textAlign: 'center' }}>Wavora is for adults 18 and over. By continuing you agree to the Terms and Community Guidelines.</Txt>
      </View>
    </Screen>
  );
}

function Steps({ step }) {
  return (
    <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}>
      {[1, 2, 3].map((i) => (
        <View key={i} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: i <= step ? c.coral : c.border }} />
      ))}
    </View>
  );
}

function StepHeader({ step, onBack }) {
  return (
    <View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Pressable accessibilityRole="button" accessibilityLabel="Back" onPress={onBack} style={{ width: 44, height: 44, marginLeft: -12, justifyContent: 'center', alignItems: 'center' }}>
          <Ionicons name="chevron-back" size={24} color={c.text} />
        </Pressable>
        <Txt w="b" size={13} color={c.muted}>Step {step} of 3</Txt>
      </View>
      <Steps step={step} />
    </View>
  );
}

export function AgeCheck({ navigation }) {
  // shortcut: no age-estimation vendor wired in yet; both buttons continue. Integrate the chosen vendor's SDK here.
  return (
    <Screen style={{ paddingHorizontal: 24, paddingBottom: 16 }}>
      <StepHeader step={2} onBack={() => navigation.goBack()} />
      <Txt w="x" size={28} style={{ marginTop: 28 }}>Confirm you're 18 or over</Txt>
      <Txt size={16} color={c.sub} style={{ marginTop: 10 }}>A quick selfie estimates your age. It takes about 10 seconds.</Txt>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <View style={{ width: 220, height: 280, borderRadius: 110, borderWidth: 3, borderStyle: 'dashed', borderColor: c.teal, alignItems: 'center', justifyContent: 'center' }}>
          <Txt color={c.muted}>Camera frame</Txt>
        </View>
      </View>
      <View style={{ gap: 8, marginBottom: 16 }}>
        <Txt size={14} color={c.sub}>✓  Your selfie is deleted as soon as the check is done.</Txt>
        <Txt size={14} color={c.sub}>✓  Going live, calls and payouts need a quick ID check later.</Txt>
      </View>
      <View style={{ gap: 10 }}>
        <Btn title="Start face check" onPress={() => navigation.navigate('ProfileSetup')} />
        <Btn kind="outline" title="Use photo ID instead" onPress={() => navigation.navigate('ProfileSetup')} />
      </View>
    </Screen>
  );
}

export function ProfileSetup({ navigation }) {
  const store = useStore();
  const [name, setName] = useState(store.profile.name);
  const [username, setUsername] = useState(store.profile.username);
  const [picked, setPicked] = useState(store.profile.interests);
  const toggle = (label) => setPicked((p) => (p.includes(label) ? p.filter((x) => x !== label) : [...p, label]));
  const validUser = /^[a-z0-9._]{3,24}$/.test(username);

  return (
    <Screen style={{ paddingHorizontal: 24, paddingBottom: 16 }}>
      <StepHeader step={3} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ paddingBottom: 16 }}>
        <Txt w="x" size={28} style={{ marginTop: 24 }}>Make it yours</Txt>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16, marginTop: 18 }}>
          <Pressable accessibilityRole="button" accessibilityLabel="Add a profile photo" style={{ width: 84, height: 84, borderRadius: 42, borderWidth: 2, borderStyle: 'dashed', borderColor: '#6E6488', backgroundColor: c.card, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="add" size={30} color={c.text} />
          </Pressable>
          <Txt size={14} color={c.sub} style={{ flex: 1 }}>Add a photo so people know it's you. You can change it any time.</Txt>
        </View>
        <Txt w="b" size={13} color={c.muted} style={{ marginTop: 18, marginBottom: 6 }}>Display name</Txt>
        <TextInput accessibilityLabel="Display name" value={name} onChangeText={setName} style={styles.input} placeholderTextColor={c.muted} />
        <Txt w="b" size={13} color={c.muted} style={{ marginTop: 12, marginBottom: 6 }}>Username</Txt>
        <TextInput accessibilityLabel="Username" autoCapitalize="none" value={username} onChangeText={(t) => setUsername(t.toLowerCase())} style={[styles.input, { borderColor: validUser ? c.teal : c.coral }]} />
        <Txt size={12} color={validUser ? c.tealText : c.coral} style={{ marginTop: 4 }}>{validUser ? 'Looks good' : '3–24 characters: letters, numbers, dots or underscores'}</Txt>
        <Txt w="b" size={13} color={c.muted} style={{ marginTop: 14, marginBottom: 8 }}>What are you into? ({picked.length} picked)</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {categories.filter((x) => x !== 'All').map((label) => (
            <Chip key={label} label={label} on={picked.includes(label)} onPress={() => toggle(label)} />
          ))}
        </View>
      </ScrollView>
      <Btn
        title="Start exploring"
        disabled={!validUser || !name.trim()}
        onPress={() => {
          store.setProfile({ name: name.trim(), username, interests: picked });
          goHome(navigation);
        }}
      />
    </Screen>
  );
}
