import React, { useState } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Badge, Chip, IconBtn, Screen, Txt, styles } from '../ui';
import { c } from '../theme';
import { categories, newStreamers, streams } from '../data';

function LiveTile({ stream, onPress }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={stream.title + ' by ' + stream.host + ', ' + stream.viewers + ' watching'} onPress={onPress} style={{ flex: 1, height: 196, borderRadius: 18, backgroundColor: stream.color, padding: 12, justifyContent: 'space-between' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Badge label="LIVE" />
        <View style={{ backgroundColor: 'rgba(20,14,32,0.6)', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}>
          <Txt size={12}>{stream.viewers} watching</Txt>
        </View>
      </View>
      <View>
        <Txt w="b">{stream.title}</Txt>
        <Txt size={13} color={c.sub}>@{stream.host}</Txt>
      </View>
    </Pressable>
  );
}

function Grid({ items, navigation }) {
  const rows = [];
  for (let i = 0; i < items.length; i += 2) rows.push(items.slice(i, i + 2));
  return (
    <View style={{ gap: 12 }}>
      {rows.map((row) => (
        <View key={row[0].id} style={{ flexDirection: 'row', gap: 12 }}>
          {row.map((s) => <LiveTile key={s.id} stream={s} onPress={() => navigation.navigate('Live', { id: s.id })} />)}
          {row.length === 1 ? <View style={{ flex: 1 }} /> : null}
        </View>
      ))}
    </View>
  );
}

export function Home({ navigation }) {
  const [feed, setFeed] = useState('For You');
  const [cat, setCat] = useState('All');
  const shown = streams.filter((s) => cat === 'All' || s.category === cat);

  return (
    <Screen edges={['top']}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 8 }}>
        <Txt w="x" size={26} color={c.coral}>wavora</Txt>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <IconBtn name="search" label="Search" onPress={() => navigation.navigate('Discover')} />
          <IconBtn name="notifications-outline" label="Notifications" onPress={() => {}} />
        </View>
      </View>
      <View accessibilityRole="tablist" style={{ flexDirection: 'row', gap: 24, paddingHorizontal: 20, marginTop: 6 }}>
        {['For You', 'Following', 'Trending'].map((t) => (
          <Pressable key={t} accessibilityRole="tab" accessibilityState={{ selected: feed === t }} onPress={() => setFeed(t)} style={{ paddingVertical: 10, borderBottomWidth: 3, borderBottomColor: feed === t ? c.coral : 'transparent' }}>
            <Txt w="b" size={16} color={feed === t ? c.text : c.muted}>{t}</Txt>
          </Pressable>
        ))}
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ gap: 8, paddingHorizontal: 20, paddingVertical: 12 }}>
        {categories.slice(0, 6).map((x) => <Chip key={x} label={x} on={cat === x} onPress={() => setCat(x)} />)}
      </ScrollView>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}>
        {shown.length ? <Grid items={shown} navigation={navigation} /> : <Txt color={c.muted} style={{ paddingVertical: 40, textAlign: 'center' }}>No one is live in {cat} right now.</Txt>}
        <Txt w="x" size={17} style={{ marginTop: 22 }}>New streamers</Txt>
        <View style={{ flexDirection: 'row', gap: 16, marginTop: 12 }}>
          {newStreamers.map((n) => (
            <Pressable key={n.id} accessibilityRole="button" onPress={() => navigation.navigate('Live', { id: 'maya' })} style={{ alignItems: 'center', gap: 6, width: 64 }}>
              <Avatar initials={n.initials} color={n.color} size={60} ring={c.gold} />
              <Txt size={12}>{n.host}</Txt>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}

export function Discover({ navigation }) {
  const [q, setQ] = useState('');
  const query = q.trim().toLowerCase();
  const results = query ? streams.filter((s) => (s.host + ' ' + s.title + ' ' + s.category).toLowerCase().includes(query)) : [];

  return (
    <Screen edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Txt w="x" size={26}>Discover</Txt>
        <View style={{ marginTop: 14, justifyContent: 'center' }}>
          <Ionicons name="search" size={18} color={c.muted} style={{ position: 'absolute', left: 16, zIndex: 1 }} />
          <TextInput accessibilityLabel="Search Wavora" value={q} onChangeText={setQ} placeholder="Search people, streams, tags" placeholderTextColor={c.muted} style={[styles.input, { borderRadius: 24, paddingLeft: 44 }]} />
        </View>
        {query ? (
          <View style={{ marginTop: 16, gap: 4 }}>
            {results.length ? results.map((s) => (
              <Pressable key={s.id} accessibilityRole="button" onPress={() => navigation.navigate('Live', { id: s.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 }}>
                <Avatar initials={s.initials} color={s.avatar} />
                <View style={{ flex: 1 }}><Txt w="b">{s.host}</Txt><Txt size={13} color={c.muted}>{s.title}</Txt></View>
                <Badge label="LIVE" />
              </Pressable>
            )) : <Txt color={c.muted}>No results for "{q}".</Txt>}
          </View>
        ) : (
          <>
            <Txt w="x" size={17} style={{ marginTop: 20, marginBottom: 10 }}>Categories</Txt>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {categories.filter((x) => x !== 'All').map((x, i) => (
                <Pressable key={x} accessibilityRole="button" onPress={() => setQ(x)} style={{ width: '31.5%', height: 56, borderRadius: 14, backgroundColor: ['#45305E', '#2B3F5E', '#5A2E3C', '#224A4C', '#4A3A22'][i % 5], alignItems: 'center', justifyContent: 'center' }}>
                  <Txt w="b" size={14}>{x}</Txt>
                </Pressable>
              ))}
            </View>
            <Txt w="x" size={17} style={{ marginTop: 22, marginBottom: 6 }}>Rising stars this week</Txt>
            {newStreamers.slice(0, 3).map((n, i) => (
              <View key={n.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 }}>
                <Txt w="x" size={16} color={c.gold} style={{ width: 20 }}>{i + 1}</Txt>
                <Avatar initials={n.initials} color={n.color} />
                <Txt w="b">{n.host}</Txt>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </Screen>
  );
}
