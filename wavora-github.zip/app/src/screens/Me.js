import React from 'react';
import { Alert, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Btn, Card, Header, IconBtn, LinkRow, Screen, ToggleRow, Txt } from '../ui';
import { c } from '../theme';
import { sparkBundles } from '../data';
import { formatGbp, formatSparks } from '../money';
import { useStore } from '../store';

export function Profile({ navigation }) {
  const store = useStore();
  const { name, username, interests } = store.profile;
  const initials = name.split(' ').map((x) => x[0]).join('').slice(0, 2).toUpperCase();

  return (
    <Screen edges={['top']}>
      <ScrollView>
        <View style={{ height: 110, backgroundColor: '#45305E', alignItems: 'flex-end', padding: 16 }}>
          <IconBtn name="settings-outline" label="Settings" bg={c.scrim} onPress={() => navigation.navigate('Settings')} />
        </View>
        <View style={{ paddingHorizontal: 20, paddingBottom: 24 }}>
          <View style={{ marginTop: -44, borderWidth: 4, borderColor: c.bg, borderRadius: 48, alignSelf: 'flex-start' }}>
            <Avatar initials={initials} color="#6B4E8F" size={88} />
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 10 }}>
            <Txt w="x" size={22}>{name}</Txt>
            <Ionicons name="checkmark-circle" size={20} color={c.teal} accessibilityLabel="Verified" />
          </View>
          <Txt size={14} color={c.muted}>@{username}</Txt>
          <Txt size={14} color={c.sub} style={{ marginTop: 6 }}>Into {interests.join(', ') || 'everything'}</Txt>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 16 }}>
            {[['18.4k', 'Followers'], ['210', 'Following'], ['142', 'Streams']].map(([v, k]) => (
              <Card key={k} style={{ flex: 1, alignItems: 'center', paddingVertical: 10 }}><Txt w="x" size={18}>{v}</Txt><Txt size={12} color={c.muted}>{k}</Txt></Card>
            ))}
          </View>
          <Btn style={{ marginTop: 14 }} title="Go Live" onPress={() => navigation.navigate('GoLive')} />
          <Card style={{ marginTop: 14 }}>
            <LinkRow label="Wallet and earnings" value={formatGbp(store.availablePence)} onPress={() => navigation.navigate('Wallet')} />
            <LinkRow label="Privacy and safety" onPress={() => navigation.navigate('Settings')} last />
          </Card>
        </View>
      </ScrollView>
    </Screen>
  );
}

export function Wallet({ navigation }) {
  const store = useStore();
  const confirmBuy = (b) => {
    Alert.alert('Buy ' + formatSparks(b.sparks) + '?', formatGbp(b.pence) + ' will be charged to your app store account.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Buy', onPress: () => { const err = store.buySparks(b); if (err) Alert.alert('Not bought', err); } },
    ]);
  };
  const withdraw = () => {
    const amount = formatGbp(store.availablePence);
    const err = store.withdraw();
    Alert.alert(err ? 'Not yet' : 'Payout on its way', err || amount + ' will arrive in about 3 working days. Bank transfers are free.');
  };
  const pct = Math.min(100, Math.round((store.spentTodayPence / store.dailyLimitPence) * 100));

  return (
    <Screen>
      <Header title="Wallet" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 4, gap: 12 }}>
        <Card style={{ padding: 16 }}>
          <Txt w="b" size={13} color={c.muted}>Sparks balance</Txt>
          <Txt w="x" size={30} color={c.gold}>{store.sparks.toLocaleString('en-GB')}</Txt>
          <Txt size={13} color={c.muted}>100 Sparks = £0.99. No timers, no surprise offers.</Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 }}>
            {sparkBundles.map((b) => (
              <Pressable key={b.sparks} accessibilityRole="button" onPress={() => confirmBuy(b)} style={{ width: '48%', padding: 12, borderRadius: 12, borderWidth: 1, borderColor: c.border }}>
                <Txt w="x" color={c.gold}>{b.sparks.toLocaleString('en-GB')}</Txt>
                <Txt size={13} color={c.sub}>{formatGbp(b.pence)}</Txt>
              </Pressable>
            ))}
          </View>
        </Card>

        <Card style={{ padding: 16 }}>
          <Txt w="b" size={13} color={c.muted}>Available to withdraw</Txt>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Txt w="x" size={30}>{formatGbp(store.availablePence)}</Txt>
            <Btn small title="Withdraw" onPress={withdraw} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}><Txt size={13} color={c.sub}>Pending · clears in 3 days</Txt><Txt w="b" size={13}>{formatGbp(store.pendingPence)}</Txt></View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}><Txt size={13} color={c.sub}>Your rate</Txt><Txt w="b" size={13}>£0.45 per 100 Sparks</Txt></View>
        </Card>

        <Card style={{ padding: 16 }}>
          <Txt w="x">Spend limit</Txt>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}><Txt size={13} color={c.sub}>Today</Txt><Txt size={13} color={c.sub}>{formatGbp(store.spentTodayPence)} of {formatGbp(store.dailyLimitPence)}</Txt></View>
          <View style={{ height: 8, borderRadius: 4, backgroundColor: c.border, marginTop: 6 }}><View style={{ width: pct + '%', height: 8, borderRadius: 4, backgroundColor: c.teal }} /></View>
        </Card>

        <Txt w="x" size={17} style={{ marginTop: 6 }}>Recent activity</Txt>
        {store.activity.map((a, i) => (
          <View key={i} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: c.line }}>
            <View style={{ flex: 1 }}><Txt w="b" size={14}>{a.title}</Txt><Txt size={12} color={c.muted}>{a.detail}</Txt></View>
            <Txt w="x" size={14}>{a.amount}</Txt>
          </View>
        ))}
      </ScrollView>
    </Screen>
  );
}

export function Settings({ navigation }) {
  const store = useStore();
  const confirmDelete = () => Alert.alert('Delete your account?', 'This permanently removes your profile, messages and replays within 30 days. It cannot be undone.', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Delete', style: 'destructive', onPress: () => navigation.reset({ index: 0, routes: [{ name: 'Welcome' }] }) },
  ]);

  return (
    <Screen>
      <Header title="Settings" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 4, gap: 8 }}>
        <Txt w="b" size={13} color={c.muted}>Privacy and safety</Txt>
        <Card>
          <LinkRow label="Who can call me" value="Followers" onPress={() => {}} />
          <LinkRow label="Who can message me" value="Verified people" onPress={() => {}} />
          <ToggleRow label="Show when I'm online" value={store.prefs.online} onChange={(v) => store.setPref('online', v)} />
          <ToggleRow label="Hidden profile" value={store.prefs.hidden} onChange={(v) => store.setPref('hidden', v)} />
          <LinkRow label="Blocked accounts" value="3" onPress={() => {}} last />
        </Card>
        <Txt w="b" size={13} color={c.muted} style={{ marginTop: 8 }}>App</Txt>
        <Card>
          <LinkRow label="Language" value="English (UK)" onPress={() => {}} />
          <LinkRow label="Video on mobile data" value="Data saver" onPress={() => {}} />
          <LinkRow label="Chat with support" onPress={() => {}} />
          <LinkRow label="Community guidelines" onPress={() => {}} last />
        </Card>
        <Pressable accessibilityRole="button" onPress={() => navigation.reset({ index: 0, routes: [{ name: 'Welcome' }] })} style={{ height: 48, justifyContent: 'center', marginTop: 8 }}>
          <Txt w="b">Log out</Txt>
        </Pressable>
        <Pressable accessibilityRole="button" onPress={confirmDelete} style={{ height: 48, justifyContent: 'center' }}>
          <Txt w="b" color="#FF8A80">Delete account</Txt>
        </Pressable>
      </ScrollView>
    </Screen>
  );
}
