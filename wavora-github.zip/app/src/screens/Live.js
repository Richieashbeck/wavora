import React, { useState } from 'react';
import { Modal, Pressable, ScrollView, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Badge, Btn, IconBtn, Txt, styles } from '../ui';
import { c } from '../theme';
import { gifts, reportReasons, streams } from '../data';
import { formatGbp, formatSparks, sparksToPence } from '../money';
import { useStore } from '../store';

function Sheet({ visible, onClose, children }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable accessibilityLabel="Close" style={{ flex: 1, backgroundColor: 'rgba(10,6,18,0.55)' }} onPress={onClose} />
      <SafeAreaView edges={['bottom']} style={{ backgroundColor: c.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 }}>
        <View style={{ width: 40, height: 5, borderRadius: 3, backgroundColor: c.border, alignSelf: 'center', marginBottom: 12 }} />
        {children}
      </SafeAreaView>
    </Modal>
  );
}

function GiftSheet({ visible, onClose, host, onSent, navigation }) {
  const store = useStore();
  const [pick, setPick] = useState('rose');
  const [error, setError] = useState(null);
  const gift = gifts.find((g) => g.id === pick);

  const send = () => {
    const err = store.sendGift(gift, host);
    setError(err);
    if (!err) { onSent(gift); onClose(); }
  };

  return (
    <Sheet visible={visible} onClose={onClose}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Txt w="x" size={20}>Send a gift</Txt>
        <Pressable accessibilityRole="button" onPress={() => { onClose(); navigation.navigate('Wallet'); }} style={{ backgroundColor: c.line, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 8 }}>
          <Txt w="b" size={14} color={c.gold}>{formatSparks(store.sparks)} · Top up</Txt>
        </Pressable>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 }}>
        {gifts.map((g) => {
          const on = g.id === pick;
          return (
            <Pressable key={g.id} accessibilityRole="button" accessibilityState={{ selected: on }} accessibilityLabel={g.name + ', ' + formatSparks(g.sparks)} onPress={() => { setPick(g.id); setError(null); }} style={{ width: '23%', alignItems: 'center', gap: 3, paddingVertical: 10, borderRadius: 14, backgroundColor: on ? '#3A2B52' : c.card, borderWidth: 2, borderColor: on ? c.gold : 'transparent' }}>
              <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: g.color, alignItems: 'center', justifyContent: 'center' }}><Txt w="x" color={c.ink}>{g.name[0]}</Txt></View>
              <Txt w="b" size={12}>{g.name}</Txt>
              <Txt w="b" size={11} color={c.gold}>{g.sparks.toLocaleString('en-GB')}</Txt>
              <Txt size={11} color={c.muted}>≈ {formatGbp(sparksToPence(g.sparks))}</Txt>
            </Pressable>
          );
        })}
      </View>
      {error ? <Txt size={13} color={c.coral} style={{ marginTop: 12 }}>{error}</Txt> : null}
      <Btn style={{ marginTop: 14, marginBottom: 8 }} title={'Send ' + gift.name + ' · ' + formatSparks(gift.sparks) + ' (≈ ' + formatGbp(sparksToPence(gift.sparks)) + ')'} onPress={send} />
    </Sheet>
  );
}

function ReportSheet({ visible, onClose, host }) {
  const [reason, setReason] = useState(null);
  const [sent, setSent] = useState(false);
  const close = () => { setSent(false); setReason(null); onClose(); };

  return (
    <Sheet visible={visible} onClose={close}>
      {sent ? (
        <View style={{ paddingVertical: 24, gap: 10 }}>
          <Txt w="x" size={20}>Thanks for telling us</Txt>
          <Txt color={c.sub}>Our safety team will review this. You'll get an update in Notifications. The host won't know it was you.</Txt>
          <Btn style={{ marginTop: 10, marginBottom: 8 }} title="Done" onPress={close} />
        </View>
      ) : (
        <>
          <Txt w="x" size={20}>Report this stream</Txt>
          <Txt size={14} color={c.muted} style={{ marginTop: 4, marginBottom: 8 }}>Reports are anonymous.</Txt>
          {reportReasons.map((r) => (
            <Pressable key={r} accessibilityRole="radio" accessibilityState={{ checked: reason === r }} onPress={() => setReason(r)} style={[styles.row, styles.rowLine, { paddingHorizontal: 4 }]}>
              <Txt>{r}</Txt>
              <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: reason === r ? 6 : 2, borderColor: reason === r ? c.coral : '#6E6488' }} />
            </Pressable>
          ))}
          <TextInput accessibilityLabel="Add details" placeholder="Add details (optional)" placeholderTextColor={c.muted} multiline style={[styles.input, { height: 64, marginTop: 12, paddingTop: 10 }]} />
          <Btn style={{ marginTop: 12 }} title="Send report" disabled={!reason} onPress={() => setSent(true)} />
          <Btn kind="outline" style={{ marginTop: 8, marginBottom: 8 }} title={'Block ' + host} onPress={() => setSent(true)} />
        </>
      )}
    </Sheet>
  );
}

export function Live({ route, navigation }) {
  const store = useStore();
  const stream = streams.find((s) => s.id === route.params?.id) || streams[0];
  const [hearts, setHearts] = useState(38000);
  const [comment, setComment] = useState('');
  const [chat, setChat] = useState([
    { who: stream.host, text: 'Taking requests until 10pm!', pinned: true },
    { who: 'sam_r', text: 'Play Yellow next please' },
    { who: 'dan.w', text: 'sent a Rocket · 600 Sparks', gift: true },
  ]);
  const [giftOpen, setGiftOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const following = !!store.following[stream.id];

  const post = () => {
    const text = comment.trim();
    if (!text) return;
    setChat((p) => [...p, { who: store.profile.username, text }]);
    setComment('');
  };

  return (
    <View style={{ flex: 1, backgroundColor: stream.color }}>
      <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, alignItems: 'center', justifyContent: 'center' }}>
        <Txt color={c.muted}>Live video</Txt>
      </View>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, paddingTop: 8 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.scrim, borderRadius: 26, padding: 4 }}>
            <Avatar initials={stream.initials} color={stream.avatar} size={40} />
            <View><Txt w="b" size={14}>{stream.host}</Txt><Txt size={12} color={c.sub}>{stream.title}</Txt></View>
            <Btn small kind={following ? 'outline' : 'primary'} title={following ? 'Following' : 'Follow'} onPress={() => store.toggleFollow(stream.id)} />
          </View>
          <View style={{ flex: 1 }} />
          <Badge label={stream.viewers} />
          <IconBtn name="close" label="Leave stream" bg={c.scrim} size={40} onPress={() => navigation.goBack()} />
        </View>

        <View style={{ marginHorizontal: 16, marginTop: 14, backgroundColor: c.scrim, borderRadius: 14, padding: 12 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Txt w="b" size={13}>Goal: new guitar strings</Txt>
            <Txt w="b" size={13} color={c.gold}>4,200 / 5,000 Sparks</Txt>
          </View>
          <View style={{ height: 8, borderRadius: 4, backgroundColor: c.border, marginTop: 8 }}>
            <View style={{ width: '84%', height: 8, borderRadius: 4, backgroundColor: c.gold }} />
          </View>
        </View>

        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 16, gap: 12 }}>
          <ScrollView style={{ flex: 1, maxHeight: 260 }} contentContainerStyle={{ gap: 8, justifyContent: 'flex-end', flexGrow: 1 }}>
            {chat.map((m, i) => (
              <View key={i} style={{ alignSelf: 'flex-start', backgroundColor: m.gift ? 'rgba(255,182,39,0.22)' : 'rgba(20,14,32,0.55)', borderWidth: m.gift ? 1 : 0, borderColor: c.gold, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6 }}>
                <Txt size={14}><Txt w="x" size={14} color={m.gift || m.pinned ? c.gold : c.tealText}>{m.pinned ? 'Pinned · ' : ''}{m.who} </Txt>{m.text}</Txt>
              </View>
            ))}
          </ScrollView>
          <View style={{ alignItems: 'center', gap: 12, paddingBottom: 4 }}>
            <IconBtn name="heart" label="Send a heart" color={c.coral} bg={c.scrim} size={48} onPress={() => setHearts((h) => h + 1)} />
            <Txt w="b" size={12} style={{ marginTop: -8 }}>{(hearts / 1000).toFixed(1)}k</Txt>
            <IconBtn name="share-outline" label="Share stream" bg={c.scrim} size={48} onPress={() => {}} />
            <IconBtn name="flag-outline" label="Report or block" bg={c.scrim} size={48} onPress={() => setReportOpen(true)} />
          </View>
        </View>

        <View style={{ flexDirection: 'row', gap: 10, padding: 16 }}>
          <TextInput accessibilityLabel="Add a comment" value={comment} onChangeText={setComment} onSubmitEditing={post} returnKeyType="send" placeholder="Say something nice…" placeholderTextColor={c.muted} style={[styles.input, { flex: 1, borderRadius: 24, backgroundColor: 'rgba(20,14,32,0.75)', borderWidth: 0 }]} />
          <IconBtn name="gift" label="Send a gift" bg={c.gold} color={c.ink} size={48} onPress={() => setGiftOpen(true)} />
        </View>
      </SafeAreaView>

      <GiftSheet visible={giftOpen} onClose={() => setGiftOpen(false)} host={stream.host} navigation={navigation} onSent={(g) => setChat((p) => [...p, { who: 'You', text: 'sent a ' + g.name + ' · ' + formatSparks(g.sparks), gift: true }])} />
      <ReportSheet visible={reportOpen} onClose={() => setReportOpen(false)} host={stream.host} />
    </View>
  );
}
