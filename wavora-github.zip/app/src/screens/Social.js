import React, { useEffect, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Badge, Btn, Card, Header, IconBtn, Screen, Txt, styles } from '../ui';
import { c } from '../theme';
import { conversations } from '../data';
import { useStore } from '../store';

export function Inbox({ navigation }) {
  const store = useStore();
  return (
    <Screen edges={['top']}>
      <Header title="Inbox" />
      <FlatList
        data={conversations}
        keyExtractor={(x) => x.id}
        renderItem={({ item }) => {
          const msgs = store.messages[item.id] || [];
          const last = msgs[msgs.length - 1];
          return (
            <Pressable accessibilityRole="button" onPress={() => navigation.navigate('Chat', { id: item.id })} style={{ flexDirection: 'row', gap: 12, paddingHorizontal: 20, paddingVertical: 14, alignItems: 'center' }}>
              <Avatar initials={item.initials} color={item.color} size={52} />
              <View style={{ flex: 1 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Txt w="b">{item.name}</Txt>
                  {item.verified ? <Ionicons name="checkmark-circle" size={16} color={c.teal} accessibilityLabel="Verified" /> : null}
                  {item.newAccount ? <Badge label="New account" bg={c.gold} /> : null}
                </View>
                <Txt size={14} color={c.sub} numberOfLines={1}>{last ? (last.from === 'me' ? 'You: ' : '') + last.text : ''}</Txt>
              </View>
              <Txt size={12} color={c.muted}>{item.time}</Txt>
            </Pressable>
          );
        }}
        ListFooterComponent={
          <Card style={{ margin: 20, padding: 14, flexDirection: 'row', gap: 10 }}>
            <Ionicons name="shield-checkmark-outline" size={20} color={c.teal} />
            <Txt size={13} color={c.sub} style={{ flex: 1 }}>Messages and calls are end-to-end encrypted. People you don't follow land in Requests, and their images arrive blurred.</Txt>
          </Card>
        }
      />
    </Screen>
  );
}

export function Chat({ route, navigation }) {
  const store = useStore();
  const convo = conversations.find((x) => x.id === route.params?.id) || conversations[0];
  const msgs = store.messages[convo.id] || [];
  const [text, setText] = useState('');
  const send = () => {
    const t = text.trim();
    if (!t) return;
    store.sendMessage(convo.id, t);
    setText('');
  };

  return (
    <Screen>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: c.line }}>
        <IconBtn name="chevron-back" label="Back" bg="transparent" onPress={() => navigation.goBack()} />
        <Avatar initials={convo.initials} color={convo.color} size={40} />
        <Txt w="b" size={16} style={{ flex: 1 }}>{convo.name}</Txt>
        <IconBtn name="call-outline" label="Voice call" bg="transparent" onPress={() => navigation.navigate('Call', { id: convo.id })} />
        <IconBtn name="videocam-outline" label="Video call" bg="transparent" onPress={() => navigation.navigate('Call', { id: convo.id })} />
      </View>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          data={msgs}
          keyExtractor={(_, i) => String(i)}
          contentContainerStyle={{ padding: 16, gap: 8 }}
          ListHeaderComponent={<Txt size={12} color={c.muted} style={{ textAlign: 'center', marginBottom: 8 }}>Messages are end-to-end encrypted</Txt>}
          renderItem={({ item }) => {
            const me = item.from === 'me';
            return (
              <View style={{ alignSelf: me ? 'flex-end' : 'flex-start', maxWidth: '75%', backgroundColor: me ? c.coral : c.line, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18, borderBottomRightRadius: me ? 6 : 18, borderBottomLeftRadius: me ? 18 : 6 }}>
                <Txt color={me ? c.ink : c.text}>{item.text}</Txt>
              </View>
            );
          }}
        />
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12, borderTopWidth: 1, borderTopColor: c.line }}>
          <TextInput accessibilityLabel="Message" value={text} onChangeText={setText} onSubmitEditing={send} returnKeyType="send" placeholder="Message" placeholderTextColor={c.muted} style={[styles.input, { flex: 1, borderRadius: 22 }]} />
          <IconBtn name="send" label="Send" bg={c.coral} color={c.ink} onPress={send} />
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}

export function Call({ route, navigation }) {
  const convo = conversations.find((x) => x.id === route.params?.id) || conversations[0];
  const [sec, setSec] = useState(0);
  const [tip, setTip] = useState(true);
  const [mic, setMic] = useState(false);
  const [cam, setCam] = useState(false);

  useEffect(() => {
    // shortcut: no real call yet; wire up WebRTC (e.g. LiveKit) with end-to-end encryption here.
    const t = setInterval(() => setSec((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: '#2B3F5E' }}>
      <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, alignItems: 'center', justifyContent: 'center' }}>
        <Txt color={c.muted}>{convo.name} video</Txt>
      </View>
      <SafeAreaView style={{ flex: 1, padding: 20 }}>
        <View style={{ alignItems: 'center', gap: 6 }}>
          <Txt w="x" size={18}>{convo.name}</Txt>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: c.scrim, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 }}>
            <Ionicons name="lock-closed" size={12} color={c.teal} />
            <Txt w="b" size={12}>End-to-end encrypted · {Math.floor(sec / 60)}:{String(sec % 60).padStart(2, '0')}</Txt>
          </View>
        </View>
        {tip ? (
          <Card style={{ marginTop: 120, padding: 16, backgroundColor: c.bg }}>
            <Txt w="x">Staying safe on calls</Txt>
            <Txt size={14} color={c.sub} style={{ marginTop: 6, marginBottom: 12 }}>Never share passwords, payment details or your address. If anyone asks you to move to another app or send money, report them.</Txt>
            <Btn small kind="light" style={{ alignSelf: 'flex-start' }} title="Got it" onPress={() => setTip(false)} />
          </Card>
        ) : null}
        <View style={{ flex: 1 }} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <IconBtn name={mic ? 'mic-off' : 'mic-outline'} label={mic ? 'Unmute' : 'Mute'} size={56} bg={mic ? c.text : c.scrim} color={mic ? c.ink : c.text} onPress={() => setMic(!mic)} />
          <IconBtn name={cam ? 'videocam-off' : 'videocam-outline'} label={cam ? 'Camera on' : 'Camera off'} size={56} bg={cam ? c.text : c.scrim} color={cam ? c.ink : c.text} onPress={() => setCam(!cam)} />
          <IconBtn name="flag-outline" label="Report or block" size={56} bg={c.scrim} onPress={() => {}} />
          <IconBtn name="call" label="End call" size={56} bg={c.danger} onPress={() => navigation.goBack()} />
        </View>
      </SafeAreaView>
    </View>
  );
}
