// Run with: node src/money.test.mjs
import assert from 'node:assert/strict';
import { sparksToPence, creatorPence, formatGbp, giftError, purchaseError, withdrawError } from './money.js';

assert.equal(sparksToPence(100), 99);
assert.equal(sparksToPence(10), 10); // 9.9p rounds to 10p
assert.equal(creatorPence(9400), 4230); // matches the stream summary design: £42.30
assert.equal(creatorPence(6940), 3123); // matches the wallet design: £31.23
assert.equal(formatGbp(31240), '£312.40');
assert.equal(giftError(1150, 600), null);
assert.match(giftError(500, 600), /Not enough/);
assert.equal(purchaseError(640, 2000, 999), null);
assert.match(purchaseError(1500, 2000, 999), /daily limit of £20.00/);
assert.match(withdrawError(1999), /£20.00/);
assert.equal(withdrawError(31240), null);
console.log('money: all checks passed');
